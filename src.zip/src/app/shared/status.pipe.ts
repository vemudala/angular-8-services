import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'status'
})
export class StatusPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    // return null;
    if(value==1){
      return "In stock"
    }else if(value==0){
      return "Out of stock"
    }
  }

}
